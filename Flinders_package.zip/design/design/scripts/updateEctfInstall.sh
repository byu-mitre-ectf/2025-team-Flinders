cd ../../
python -m pip install ./tools
python -m pip install ./design
