# python ../ectf25_design/encoder.py ../../global.secrets/secrets.bin 1 "frame to encode" 100
python ../ectf25_design/encoder.py ../../global.secrets 1 "frame to encode" 100
