python -m ectf25.utils.stress_test --test-size=10000000 encode --dump="./enc_frames.bin" "../../global.secrets"
