python -m ectf25.utils.flash ./deadbeef_build/max78000.bin /dev/ttyACM0
