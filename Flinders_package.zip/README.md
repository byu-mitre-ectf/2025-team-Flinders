# Attack Package
## Attacker Decoder
 - Binary: attacker.prot
 - Decoder ID: 0x880fa1d8
 - own.sub: Subscription to channel 1
 - expired.sub: Expired subscription to channel 2

## Pirated Decoder
 - Binary not provided
 - Decoder ID: 0x77315ef5
 - pirated.sub: Subscription to channel 3

## Neighbor Decoder
 - Binary not provided
 - Decoder ID: 0x75f982a4
 - Subscription not provided
